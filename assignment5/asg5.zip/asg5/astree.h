// $Id: astree.h,v 1.7 2016-10-06 16:13:39-07 - - $

#ifndef __ASTREE_H__
#define __ASTREE_H__

#include <string>
#include <vector>
#include <bitset>
#include <unordered_map>
using namespace std;

#include "auxlib.h"

struct location {
   size_t filenr;
   size_t linenr;
   size_t offset;
};

enum { ATTR_void, ATTR_int, ATTR_null, ATTR_char, ATTR_string,
   ATTR_struct, ATTR_array, ATTR_bool, ATTR_function, ATTR_variable,
   ATTR_field, ATTR_typeid, ATTR_param, ATTR_lval, ATTR_const,
   ATTR_vreg, ATTR_vaddr, ATTR_bitset_size,
   };
using attr_bitset = bitset<ATTR_bitset_size>;

struct symbol;

struct astree {
   // Fields.
   int symbol;               // token code
   location lloc;            // source location
   size_t blocknr;
   const string* lexinfo;    // pointer to lexical information
   vector<astree*> children; // children of this n-way node
   attr_bitset attributes;
   const string* strType;
   struct symbol* sym;
   string vreg;
   // Functions.
   astree (int symbol, const location&, const char* lexinfo);
   ~astree();
   astree* adopt (astree* child1, astree* child2 = nullptr);
   astree* adopt_sym (astree* child, int symbol);
   astree* adopt_sym2 (astree* child, int symbol_);
   
   void dump_node (FILE*);
   void dump_tree (FILE*, int depth = 0);
   static void dump (FILE* outfile, astree* tree);
   static void print (FILE* outfile, astree* tree, int depth = 0);
};
astree* swap_symb(astree* root, int symbol);
void destroy (astree* tree1, astree* tree2 = nullptr);

void errllocprintf (const location&, const char* format, const char*);



#endif

