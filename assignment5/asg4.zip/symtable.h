#ifndef __SYMTABLE_H__
#define __SYMTABLE_H__

#include <string>
#include <vector>
#include <bitset>
#include <unordered_map>

#include "astree.h"


struct symbol;
using symbol_table = unordered_map<const string*, symbol*>;
using symbol_entry = pair<const string*, symbol*>;
struct symbol {
   attr_bitset attributes;
   symbol_table* fields;
   location lloc;
   size_t blocknr;
   vector<symbol_table>* parameters;
};
void push_block();
void pop_block();
void define_ident(astree* node);
symbol* stack_find_ident(astree* node);
char* strd(const char* s);
char* get_attributes(attr_bitset attributes);
void check_prototype(FILE* outfile, astree* node);
void check_block(astree* node);
void check_function(FILE* outfile, astree* node);
void print_symbol(FILE* outfile, astree* node);
symbol* new_symbol(astree* node);
void insert_symbol(symbol_table* sym, astree* node);
symbol* lookup(symbol_table* symtab, astree* node);
bool compatible(astree* left, astree* right);
void adopt_type(astree* child, astree* parent);
void adopt_attribute(astree* child, astree* parent);
void semantic_analysis(FILE* outfile, astree* node);
void rtypecheck(FILE* outfile, astree* node);
void typecheck(FILE* outfile, astree* node);
#endif
