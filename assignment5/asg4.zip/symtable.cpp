#include <iostream>
#include <string>
#include <vector>
#include <bitset>
#include <unordered_map>
#include <string.h>
#include <stdlib.h>
using namespace std;
#include "symtable.h"
#include "astree.h"
#include "lyutils.h"
#include "auxlib.h"
size_t nextsym;
vector<symbol_table*> stack;
symbol_table* st = new symbol_table;



void push_block(){
   nextsym++;
   stack.push_back(nullptr);
}
void pop_block(){
   stack.pop_back();    
}
void define_ident(astree* node) {
    if (stack.back() == nullptr) {
        stack.back() = new symbol_table;
    }
    insert_symbol(stack.back(), node);
}

symbol* stack_find_ident(astree* node) {
    for (auto table : stack) {
        if (table != nullptr && !(table->empty())) {
            if (lookup(table, node) != nullptr) {
                return lookup(table, node);
            }
        }
    }
    return nullptr;
}

char* strd(const char* s){
  int slen = strlen(s);
  char* result = (char*) malloc(slen + 1);
  if(result == NULL){
    return NULL;
  }

  memcpy(result, s, slen+1);
  return result;
}
char* get_attributes(attr_bitset attributes) {
    string str = "";

    if (attributes.test (ATTR_void))        str += "void ";
    if (attributes.test (ATTR_bool))        str += "bool ";
    if (attributes.test (ATTR_char))        str += "char ";
    if (attributes.test (ATTR_int))         str += "int ";
    if (attributes.test (ATTR_null))        str += "null ";
    if (attributes.test (ATTR_string))      str += "string ";
    if (attributes.test (ATTR_struct))      str += "struct ";
    if (attributes.test (ATTR_array))       str += "array ";
    if (attributes.test (ATTR_function))    str += "function ";
    if (attributes.test (ATTR_variable))    str += "variable ";
    if (attributes.test (ATTR_typeid))      str += "typeid ";
    if (attributes.test (ATTR_param))       str += "param ";
    if (attributes.test (ATTR_lval))        str += "lval ";
    if (attributes.test (ATTR_const))       str += "const ";
    if (attributes.test (ATTR_vreg))        str += "vreg ";
    if (attributes.test (ATTR_vaddr))       str += "vaddr ";
    return strd(str.c_str());
}

symbol* new_symbol(astree* node){
   symbol* sym = new symbol();
   sym->attributes = node->attributes;
   sym->lloc = node->lloc;
   sym->blocknr = node->blocknr;
   return sym;
}
void insert_symbol(symbol_table* symtab, astree* node){
   symbol* sym = new_symbol(node);      
   if ((symtab!=NULL) && (node!=NULL)) {
        symtab->insert( symbol_entry(node->lexinfo, sym));
    }
}
symbol* lookup(symbol_table* symtab, astree* node) {
   if(symtab->count(node->lexinfo) == 0){
      return nullptr;      
   }
   else
   return(symtab->find(node->lexinfo))->second;
}

void check_prototype(FILE* outfile, astree* node) {
    node->children[0]->children[0]->attributes.set(ATTR_function);
    insert_symbol(stack[0], node->children[0]->children[0]);
    //print_symbol (symbol_stack[0], node->children[0]->children[0]);
    push_block();

    for (auto child : node->children[1]->children) {
        child->children[0]->attributes.set (ATTR_variable);
        child->children[0]->attributes.set (ATTR_lval);
        child->children[0]->attributes.set (ATTR_param);
        child->children[0]->blocknr = nextsym;
        define_ident (child);
        print_symbol(outfile, child->children[0]);
    }
    pop_block();
}

void check_block(astree* node) {
    if (node->symbol == TOK_BLOCK) {
        push_block();
    }
    node->blocknr = nextsym;
    for (auto child : node->children) {
        check_block (child);
    }
}

void check_function(FILE* outfile, astree* node) {
    node->children[0]->children[0]->attributes.set (ATTR_function);
    insert_symbol (stack[0], node->children[0]->children[0]);
    //print_symbol (stack[0], node->children[0]->children[0]);
    
    for (auto child : node->children[1]->children) {
        child->children[0]->attributes.set (ATTR_variable);
        child->children[0]->attributes.set (ATTR_lval);
        child->children[0]->attributes.set (ATTR_param);
        child->children[0]->blocknr = nextsym;
        define_ident (child->children[0]);
        print_symbol (outfile, child->children[0]);
    }

    check_block(node->children[2]);
    pop_block();
}

astree* current_struct = nullptr;
void print_symbol(FILE* outfile, astree* node) {
    attr_bitset attributes = node->attributes;

    if (node->attributes[ATTR_struct]) {
        fprintf (outfile, "\n");
    } else {
        fprintf (outfile, "    ");
    }

    if (node->attributes[ATTR_field]) {
        fprintf (outfile, "%s (%zu.%zu.%zu) field {%s} ",
            (node->lexinfo)->c_str(),
            lexer::lloc.linenr, lexer::lloc.filenr, lexer::lloc.offset,
            (current_struct->lexinfo)->c_str());
    } else {
          
        fprintf (outfile, "%s (%zu.%zu.%zu) {%zu} ",
            (node->lexinfo)->c_str(),
            lexer::lloc.linenr, lexer::lloc.filenr, lexer::lloc.offset,
            node->blocknr);
    }

    if (node->attributes[ATTR_struct]) {
        fprintf (outfile, "struct \"%s\" ", 
            ( node->lexinfo)->c_str());
        current_struct = node;
    }

    fprintf (outfile, "%s\n", get_attributes(node->attributes));
}


/*
symbol* symbol_for_type(astree* node, bool isArray) {
   
}

*/
bool compatible(astree* left, astree* right) {
   for(size_t i = 0; i < ATTR_function; i++){
      if(left->attributes[i] == 1 && right->attributes[i] == 1){
         return 1;            
      }
   }
   return 0;
}

void adopt_type(astree* child, astree* parent){
   for(size_t i = 0; i < ATTR_function; i++){
      if(child->attributes[i] == 1){
         parent->attributes[i];       
      }
   }
}
void adopt_attribute(astree* child, astree* parent){
   for(size_t i = 0; i < ATTR_bitset_size; i++){
      if(child->attributes[i] == 1){
         parent->attributes[i];       
      }
   }    
}

void semantic_analysis(FILE* outfile, astree* node) {
   astree* left;
   astree* right;
   symbol* symbol;
   //fprintf(outfile, "we are in semantic analysis\n");
   if(node->children.size() > 0){
      left = node->children[0];    
   }
   if(node->children.size() > 1){
      right = node->children[1];           
   }
   //fprintf(outfile, "we are in semantic analysis\n");
   DEBUGF('q', "node->symbol is %d, or %s \n", 
           node->symbol, parser::get_tname(node->symbol));
   switch(node->symbol){
      case TOK_VOID: 
         DEBUGF( 'q', "I am void \n");  
         left->attributes[ATTR_void]=1;
         adopt_type(node, left);
         break;
      case TOK_CHAR:
         if(left==nullptr) break;
         left->attributes[ATTR_char]=1;
         adopt_type(node, left);
         break;
      case TOK_INT:
         DEBUGF('q', "case int \n");
         if(left==nullptr) break;
         left->attributes[ATTR_int]=1;
         adopt_type(node, left);
         //fprintf(outfile, "we are in int\n");
         break;
      case TOK_STRING:
         if(left==nullptr) break;
         left->attributes[ATTR_string]=1;
         adopt_type(node, left);
         break;               
      case TOK_IF:            
      case TOK_ELSE:              
      case TOK_IFELSE:
         if(left->attributes[ATTR_bool] == 0){
            errprintf("Error, must be bool\n");   
         }
         break;
      case TOK_WHILE:
         if(left->attributes[ATTR_bool] == 0){
            errprintf("Error, must be bool\n");   
         }
         break;
      case TOK_RETURN:
         DEBUGF('q', "I am in return \n");
         //fprintf(outfile, "we are in return\n");
         break;               
      case TOK_STRUCT:
         DEBUGF('q', "I am in case struct \n");
         left->attributes[ATTR_struct]=1;
         insert_symbol(st, left);
         print_symbol(outfile, left);
         symbol = 
                lookup(st, left);
            symbol->fields = new symbol_table;
         for (auto n = node->children.begin()+1;
                n != node->children.end(); n++) {
                insert_symbol(symbol->fields, *n);
                print_symbol(outfile, (*n)->children[0]);
            } 
         break;
      case TOK_NULL:
         node->attributes[ATTR_null]=1;
         node->attributes[ATTR_const]=1;
         break;               
      case TOK_NEW:
          adopt_attribute(node, left);
          break;
      case TOK_ARRAY:
         left->attributes[ATTR_array]=1;
         if (left == nullptr || 
                left->children.empty())                     
                break;
            left->children[0]->attributes.set(ATTR_array); 
            break;                    
      case TOK_EQ:
      case TOK_NE:   
      case TOK_LT:            
      case TOK_LE:   
      case TOK_GT:   
      case TOK_GE:
         if(compatible(left, right)){
            node->attributes[ATTR_bool]=1;       
         }
         else{
            errprintf("Error, incompatible types\n");    
         }
         break;
      case TOK_IDENT: 
         symbol = stack_find_ident(node);

            if (symbol == nullptr) {
                lookup(st, node);
            }
         if(symbol==nullptr){
                errprintf("identifier not found\n"); 
                break;
         }
         node->attributes = symbol->attributes;          
         break;
      case TOK_INTCON: 
         node->attributes[ATTR_int]=1;
         node->attributes[ATTR_const]=1;
         break;   
      case TOK_CHARCON: 
         node->attributes[ATTR_char]=1;
         node->attributes[ATTR_const]=1;
         break;     
      case TOK_STRINGCON:
         node->attributes[ATTR_string]=1;
         node->attributes[ATTR_const]=1;
         break;    
      case TOK_BLOCK: 
         check_block(node);
         pop_block();
         break;
      case TOK_INITDECL: 
         break;     
      case TOK_FUNC:
         push_block();
         check_function(outfile, node);
         print_symbol(outfile, node);
         break;    
      case TOK_POS:       
      case TOK_NEG:
         break;               
      case TOK_NEWARRAY:
         node->attributes[ATTR_vreg]=1;
         node->attributes[ATTR_array]=1;
         adopt_type(node, left);
         break;               
      case TOK_TYPEID: 
         node->attributes[ATTR_typeid]=1;
         break;               
      case TOK_FIELD: 
         DEBUGF ('q', "check 0 \n");
         node->attributes[ATTR_field]=1;
         DEBUGF ('q', "check 1 \n");
         if(left != nullptr){
            DEBUGF ('q', "check 1.5 \n");
            //left->attributes[ATTR_field]=1;
            DEBUGF ('q', "check 2 \n");
            adopt_type(node, left);
            DEBUGF ('q', "check 3 \n");
         }DEBUGF ('q', "check 4 \n");
         break;               
      case TOK_INDEX:
         node->attributes[ATTR_lval]=1;
         node->attributes[ATTR_vaddr]=1;
         break;               
      case TOK_ORD: 
         node->attributes[ATTR_int]=1;
         node->attributes[ATTR_vreg]=1;
         break;               
      case TOK_CHR: 
         node->attributes[ATTR_char]=1;
         node->attributes[ATTR_vreg]=1;
         break;
      case TOK_ROOT: 
                DEBUGF('q', "we are in root \n");             
      case TOK_DECLID: 
         break;               
      case TOK_VARDECL: 
         left->children[0]->attributes[ATTR_lval] = 1;
         left->children[0]->attributes[ATTR_variable] = 1;
         //DEBUGF ('q', "check 1 \n");
         adopt_attribute(node, left);
         if (stack_find_ident(left->children[0])) {
            errprintf("Error, variable already declared\n");     
         }
         //DEBUGF ('q', "Check 2 \n");
         //define_ident(left->children[0]);
         //DEBUGF ('q', "Check 3 \n");
         print_symbol(outfile, left->children[0]);
         //DEBUGF ('q', "Check 4 \n");
         break;               
      case TOK_PRAM:
         node->attributes[ATTR_param]=1;
         break;               
      case TOK_RETURNVOID: 
         break;               
      case TOK_PROTOTYPE: 
         check_prototype(outfile, node);
         break;               
      case TOK_NEWSTRING:
         node->attributes[ATTR_vreg]=1;
         node->attributes[ATTR_string]=1;
         break;     
      case TOK_CALL: 
         //DEBUGF ('q', "check 0 \n");      
         symbol = lookup(st,
                               node->children.back());
         //DEBUGF ('q', "check 1 \n");
         if (symbol == nullptr) {
             errprintf ("Error, function not found\n");
             break;
         }
         //DEBUGF ('q', "check 2 \n");
         for (size_t i = 0; i < ATTR_function; i++) {
                    DEBUGF ('q', "check 4 \n");
             if (symbol->attributes[i] == 1) {
                 node->attributes.set (i);
             }
         } //DEBUGF ('q', "check 3 \n");
         break;
      case '(':
      case '[':
         break;
      case '+':
      case '-':
         node->attributes[ATTR_int]=1;
         node->attributes[ATTR_vreg]=1;
         if (right == nullptr) {
                if (left == nullptr) break;
                if (!(left->attributes[ATTR_int])) {
                    errprintf ("Error, type int req'd\n");
                }
            } else {
                if (!(left->attributes[ATTR_int]) ||
                    !(right->attributes[ATTR_int])) {
                    errprintf ("Error, type int req'd\n");
                }
            }                                               
            break;

      case '*':
      case '/':       
      case '%':
         node->attributes[ATTR_int]=1;
         node->attributes[ATTR_vreg]=1;
         if (!(left->attributes[ATTR_int]) ||
                !(right->attributes[ATTR_int])) {
                errprintf ("Error, type int req'd\n");
            }                                               
            break;
      case '!':
         node->attributes.set (ATTR_vreg);
         node->attributes.set (ATTR_bool);
         if (!(left->attributes[ATTR_int])) {
                errprintf("Error, bool req'd\n");
         }
         break;
      case '^':
         break;
      case '.':
         node->attributes.set (ATTR_lval);
         node->attributes.set (ATTR_vaddr);
         symbol = lookup(st, node);
         adopt_type(node, left);                      
         break;
      case '=':
         if (left == nullptr) break;
            if (left->attributes[ATTR_lval] && 
                right->attributes[ATTR_vreg]) {
                adopt_type(node, left);
                node->attributes.set (ATTR_vreg);
            } else {
                errprintf ("Error, incompatible types\n");
            }                                              
            break;     
      default:
            errprintf ("Error, invalid token \"%s\"",
                parser::get_tname(node->symbol));
   }
}
void rtypecheck(FILE* outfile, astree* node){
   for(auto child: node->children){
      rtypecheck(outfile, child);          
   }
   semantic_analysis(outfile, node);
}
void typecheck(FILE* outfile, astree* node){
   rtypecheck(outfile, node);
   while(!stack.empty()){
      pop_block();         
   }
}

