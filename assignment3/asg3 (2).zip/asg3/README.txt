This is for assignment 2
This program was completed using pair programming.
Megan Sharp (mesharp@ucsc.edu)
Michelle Ly (mly8@ucsc.edu)

We acknowledge that each partner in a programming pair should
drive roughly 50% of the time the pair is working together, and
at most 25% of an individual's effort for an assignment should
be spent working alone.  Any work done by a solitary programmer
must be reviewed by the partner.  The object is to work
together, learning from each other, not to divide the work|into
two pieces with each partner working on a different piece.

Megan Sharp spent     _0__ hours working alone.
Michelle Ly spent     _0__ hours working alone.
We spent              _20_ hours working together.
Megan Sharp spent     _10_ hours driving.
Michelle LY spent     _10_ hours driving.

Please grade the work submitted by mesharp@ucsc.edu
and not the work submitted by mly8@ucsc.edu